class Vehicle:
    def __init__(self, owner, model, plate_number):
        self.owner = owner
        self.model = model
        self.plate_number = plate_number